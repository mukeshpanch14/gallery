from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
from .forms import ImageForm
from .models import Image
# Create your views here.

def index(request):
    return HttpResponse('Hey Mukesh!')

def upload(request):
    context={}
    if request.method=='POST':
        uploaded_file=request.FILES['image']
        fs=FileSystemStorage()
        name=fs.save(uploaded_file.name,uploaded_file)
        url=fs.url(name)
        context['url']=url
    return render(request,'upload.html',context)

def image_list(request):
    images=Image.objects.all()
    return render(request,'allimages.html',{
        'images':images
    })

def image_upload(request):
    if request.method=='POST':
        form=ImageForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('image_list')
    else:
        form=ImageForm()
    return render(request,'upload_image.html',{
        'form':form
    })


